#include "bridge.hpp"

amdgpu::bridge::BridgePusher rx::bridge;
