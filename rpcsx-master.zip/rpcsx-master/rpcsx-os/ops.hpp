#pragma once

#include "orbis/thread/ProcessOps.hpp"

namespace rx {
extern orbis::ProcessOps procOpsTable;
}
