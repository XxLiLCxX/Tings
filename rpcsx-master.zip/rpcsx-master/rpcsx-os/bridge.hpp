#pragma once

#include <amdgpu/bridge/bridge.hpp>

namespace rx {
extern amdgpu::bridge::BridgePusher bridge;
}
