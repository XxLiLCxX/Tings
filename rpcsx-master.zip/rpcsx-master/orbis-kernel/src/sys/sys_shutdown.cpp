#include "sys/sysproto.hpp"

orbis::SysResult orbis::sys_reboot(Thread *thread, sint opt) {
  return ErrorCode::NOSYS;
}
