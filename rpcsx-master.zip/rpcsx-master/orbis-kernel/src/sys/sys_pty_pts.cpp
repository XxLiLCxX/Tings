#include "sys/sysproto.hpp"

orbis::SysResult orbis::sys_posix_openpt(Thread *thread, sint flags) {
  return ErrorCode::NOSYS;
}
