#include "sys/sysproto.hpp"

orbis::SysResult orbis::sys_pipe(Thread *thread) { return ErrorCode::NOSYS; }
