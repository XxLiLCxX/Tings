#pragma once

#include <cstdint>

namespace orbis {
enum class ModuleHandle : std::uint32_t {};
} // namespace orbis
