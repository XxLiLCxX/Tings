#pragma once

namespace amdgpu::shader {
enum class BufferKind { VBuffer, TBuffer };
}
