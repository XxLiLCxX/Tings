#pragma once

namespace amdgpu::shader {
enum class Stage { None, Vertex, Fragment, Geometry, Compute };
}
